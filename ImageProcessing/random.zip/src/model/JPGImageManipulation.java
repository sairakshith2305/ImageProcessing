package model;

/**
 * This is a class that supports JPG/PNG and JPEG formats. Any new additions specific to the
 * JPEG/PNG/JPG formats can be added to this class.
 */
public class JPGImageManipulation extends AbstractImageManipulation {


}
