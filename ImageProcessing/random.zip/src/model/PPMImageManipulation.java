package model;

/**
 * This is a class that supports PPM formats. Any new additions specific to the
 * PPM formats can be added to this class. The remaining functionality offered by this class
 * has been abstracted.
 */
public class PPMImageManipulation extends AbstractImageManipulation {

}
